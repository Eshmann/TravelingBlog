﻿using System.Linq;
using Empty.Models;

namespace Empty
{
    public static class SampleData
    {
        public static void Initialize(BlogContext context)
        {
            if (!context.Users.Any())
            {
                context.Users.AddRange(
                    new User
                    {
                        Name = "Tom",
                        Age = 27,
                        Country = "USA",
                        Email = "tom123@gmail.com",
                        NumOfTrips = 9,
                        NumOfSubscribers = 119
                    },
                    new User
                    {
                        Name = "Emily",
                        Age = 22,
                        Country = "Australia",
                        Email = "emily456@gmail.com",
                        NumOfTrips = 13,
                        NumOfSubscribers = 352
                    },
                    new User
                    {
                        Name = "Harry",
                        Age = 30,
                        Country = "England",
                        Email = "harry789@gmail.com",
                        NumOfTrips = 22,
                        NumOfSubscribers = 575
                    }
                );
                context.SaveChanges();
            }
        }
    }
}