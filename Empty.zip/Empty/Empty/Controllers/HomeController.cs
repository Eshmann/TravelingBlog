﻿using System;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using Empty.Models;

namespace Empty.Controllers
{
    public class HomeController : Controller
    {
        BlogContext db;
        public HomeController(BlogContext context)
        {
            db = context;
        }
        public IActionResult Index()
        {
            return View(db.Users.ToList());
        }

        [HttpGet]
        public IActionResult CreateTrip(int id)
        {
            ViewBag.UserId = id;
            return View();
        }

        [HttpPost]
        public string CreateTrip(Trip trip)
        {
            trip.CreateDate = DateTime.Now;
            db.Trips.Add(trip);
            db.SaveChanges();
            return $"{trip.User}, your trip was created!";
        }
    }
}