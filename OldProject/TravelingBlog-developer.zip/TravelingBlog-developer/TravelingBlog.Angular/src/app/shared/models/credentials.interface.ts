export interface Credentials {
  email: string;
  password: string;
}
