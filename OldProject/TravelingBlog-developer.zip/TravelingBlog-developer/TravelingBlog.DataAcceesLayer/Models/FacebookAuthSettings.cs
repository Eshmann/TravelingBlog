﻿namespace TravelingBlog.DataAcceesLayer.Models
{
    public class FacebookAuthSettings
    {
        public string AppId { get; set; }
        public string AppSecret { get; set; }
    }
}
