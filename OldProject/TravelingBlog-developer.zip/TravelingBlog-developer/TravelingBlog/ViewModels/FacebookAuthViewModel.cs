﻿namespace TravelingBlog.ViewModels
{
    public class FacebookAuthViewModel
    {
        public string AccessToken { get; set; }
    }
}
